Ext.define('Errors.view.Main', {
    extend: 'Ext.Panel',
    xtype: 'main',
    requires: [
        
    ],
    config: {
       

        items: [
           {
				xtype: 'button',
				id: 'btnTap',
				text: 'Click Me'
		   }
        ]
    }
});
