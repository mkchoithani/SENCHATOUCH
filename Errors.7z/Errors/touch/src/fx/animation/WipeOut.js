/**
 * @private
 */
Ext.define('Ext.fx.animation.WipeOut', {
    extend: 'Ext.fx.animation.Wipe',

    config: {
        // @hide
        out: true
    }
});