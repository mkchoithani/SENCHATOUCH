Ext.define('Internationalization.view.Main', {
	extend : 'Ext.Panel',
	xtype : 'main',
	requires : [

	],
	config : {
		styleHtmlContent: true,
		items : [{
				xtype : 'panel',
				width : '100%',
				items : [ {
						xtype : 'textfield',
						placeHolder : fetch.login.username,
						id : 'usernametxtfld',
						
					},{
						xtype : 'spacer',
						height : 20
					}, {
						xtype : 'textfield',
						placeHolder : fetch.login.password,
						id : 'passwordtxtfld',
						
					}, {
						xtype : 'spacer',
						height : 20
					}, {
						xtype : 'button',
						text : fetch.login.login,
						id : 'loginBtn',
						ui : 'action',
						
					}
				]
			}
		]
	}
});
