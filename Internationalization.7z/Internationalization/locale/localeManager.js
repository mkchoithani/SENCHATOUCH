﻿	var browserLang = window.navigator.language || window.navigator.userLanguage || window.navigator.browserLanguage || window.navigator.systemLanguage; // get the browsers language
	//alert(browserLang);
	var locales = ['en-US', 'fr','en']; 						// available locale files
	var locale = 'en-US'; 								// default locale

	// check browser language against available locale files
	for (var i = locales.length - 1; i >= 0; i--) {		//check if the locale file is available
		if (browserLang == locales[i]) {
			locale = browserLang;						//assign browser language to the variable locale
			//alert('manager');
			//alert(locale+'selected');
			break;
		}
	};
	if(locale=='en')
	{
	locale='en-US'
	}
	//alert(extlocale);
	//even if locale isn't available, we have set en-US value in the locale variable
	extlocale.src='locale/ext-lang-'+locale+'.js';	//fetch the respective locale file from locale folder