/**
 * @private
 */
Ext.define('Ext.carousel.Item', {
    extend: 'Ext.Decorator',

    config: {
        baseCls: 'x-carousel-item',
        component: null,
        translatable: true
    }
});
